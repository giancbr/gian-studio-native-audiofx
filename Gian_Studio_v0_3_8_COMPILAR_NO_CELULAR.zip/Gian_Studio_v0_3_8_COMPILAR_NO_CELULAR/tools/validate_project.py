from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
checks={
 'audio bridge registration': ('audiofxbase/src/main/java/com/exemple/template/MainActivity.java', 'addJavascriptInterface(new AudioFxBridge(), "GianCrystalAudioFX")'),
 'equalizer': ('audiofxbase/src/main/java/com/exemple/template/GlobalAudioFxEngine.java', 'new Equalizer(1000, GLOBAL_SESSION_ID)'),
 'bass boost': ('audiofxbase/src/main/java/com/exemple/template/GlobalAudioFxEngine.java', 'new BassBoost(1000, GLOBAL_SESSION_ID)'),
 'loudness': ('audiofxbase/src/main/java/com/exemple/template/GlobalAudioFxEngine.java', 'new LoudnessEnhancer(GLOBAL_SESSION_ID)'),
 'audio permission': ('audiofxbase/src/main/AndroidManifest.xml', 'android.permission.MODIFY_AUDIO_SETTINGS'),
 'base injection': ('tools/prepare_compiler_asset.py', 'BLACK5_BASE_APK_B64'),
 'workflow': ('.github/workflows/build-gian-studio.yml', ':audiofxbase:assembleDebug'),
}
failed=[]
for label,(path,needle) in checks.items():
 text=(root/path).read_text('utf8')
 if needle not in text: failed.append(label)
 print(('OK  ' if needle in text else 'FAIL'),label)
if failed: raise SystemExit('Falhas: '+', '.join(failed))
print('Estrutura validada.')
