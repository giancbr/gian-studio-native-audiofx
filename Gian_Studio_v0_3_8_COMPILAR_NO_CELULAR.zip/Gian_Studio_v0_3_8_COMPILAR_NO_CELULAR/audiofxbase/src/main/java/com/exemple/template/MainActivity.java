package com.exemple.template;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.audiofx.AudioEffect;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 901;
    private static final int PERMISSION_REQUEST = 902;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private final GlobalAudioFxEngine audioFx = new GlobalAudioFxEngine();

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new PlayerChromeClient());
        webView.addJavascriptInterface(new AudioFxBridge(), "GianCrystalAudioFX");
        webView.addJavascriptInterface(new NativeInfoBridge(), "GianNative");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
        requestMediaPermissions();
    }

    private void requestMediaPermissions() {
        if (android.os.Build.VERSION.SDK_INT < 23) return;
        String[] permissions = {Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO};
        boolean missing = false;
        for (String permission : permissions) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) missing = true;
        }
        if (missing) requestPermissions(permissions, PERMISSION_REQUEST);
    }

    private final class PlayerChromeClient extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            Intent intent;
            try {
                intent = params.createIntent();
            } catch (Throwable error) {
                intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }
            try {
                startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                return true;
            } catch (ActivityNotFoundException error) {
                fileCallback = null;
                Toast.makeText(MainActivity.this, "Nenhum seletor de arquivos disponível", Toast.LENGTH_LONG).show();
                return false;
            }
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            runOnUiThread(() -> request.grant(request.getResources()));
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            setContentView(view);
        }

        @Override
        public void onHideCustomView() {
            setContentView(webView);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || fileCallback == null) return;
        Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        audioFx.release();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private boolean openSystemPanel() {
        try {
            Intent intent = new Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL);
            intent.putExtra(AudioEffect.EXTRA_AUDIO_SESSION, GlobalAudioFxEngine.GLOBAL_SESSION_ID);
            intent.putExtra(AudioEffect.EXTRA_PACKAGE_NAME, getPackageName());
            intent.putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC);
            startActivityForResult(intent, 903);
            return true;
        } catch (Throwable first) {
            try {
                startActivity(new Intent(Settings.ACTION_SOUND_SETTINGS));
                return true;
            } catch (Throwable ignored) {
                return false;
            }
        }
    }

    public final class AudioFxBridge {
        @JavascriptInterface public String getStatusJson() { audioFx.initialize(); return audioFx.statusJson(); }
        @JavascriptInterface public String getStatus() { return getStatusJson(); }
        @JavascriptInterface public boolean setEnabled(boolean value) { return audioFx.setEnabled(value); }
        @JavascriptInterface public boolean setGlobalEnabled(boolean value) { return setEnabled(value); }
        @JavascriptInterface public boolean enable(boolean value) { return setEnabled(value); }
        @JavascriptInterface public boolean setBand(int index, double db) { return audioFx.setBand(index, db); }
        @JavascriptInterface public boolean setEqualizerBand(int index, double db) { return setBand(index, db); }
        @JavascriptInterface public boolean setBass(double db) { return audioFx.setBass(db); }
        @JavascriptInterface public boolean setBassBoost(double db) { return setBass(db); }
        @JavascriptInterface public boolean setGain(double db) { return audioFx.setGain(db); }
        @JavascriptInterface public boolean setGainDb(double db) { return setGain(db); }
        @JavascriptInterface public boolean setLoudness(double db) { return setGain(db); }
        @JavascriptInterface public boolean openSystemEqualizer() { return openSystemPanel(); }
        @JavascriptInterface public boolean openEqualizerPanel() { return openSystemPanel(); }
    }

    public final class NativeInfoBridge {
        @JavascriptInterface public String nativeVersion() { return "Gian Native AudioFX Base 0.3.8"; }
        @JavascriptInterface public int mediaVolume() {
            AudioManager manager = (AudioManager) getSystemService(AUDIO_SERVICE);
            return manager == null ? -1 : manager.getStreamVolume(AudioManager.STREAM_MUSIC);
        }
    }
}
