# Gian Studio Offline Compiler v0.3.8 — Native AudioFX

Esta versão corrige o problema da v0.3.7: o Java nativo não é colocado como arquivo comum dentro do projeto. Ele é compilado **antes** e passa a fazer parte da base Android usada em todos os APKs gerados.

## Arquitetura

1. `audiofxbase` gera uma base Android com:
   - `GianCrystalAudioFX` registrado por `addJavascriptInterface`;
   - `Equalizer`, `BassBoost` e `LoudnessEnhancer`;
   - seletor de arquivos para músicas locais;
   - WebView, câmera e microfone.
2. `prepare_compiler_asset.py` incorpora o APK dessa base no HTML do Gian Studio.
3. `compiler` gera o APK final do Gian Studio v0.3.8.
4. Todo `index.html` compilado pela v0.3.8 recebe a ponte nativa automaticamente.

## Gerar pelo GitHub usando o celular

1. Crie um repositório vazio no GitHub.
2. Envie todo o conteúdo deste ZIP para a raiz do repositório.
3. Abra **Actions**.
4. Selecione **Gerar Gian Studio Native AudioFX**.
5. Toque em **Run workflow**.
6. Ao terminar, abra a execução e baixe o artefato **Gian-Studio-v0.3.8-Native-AudioFX**.
7. Dentro dele estará `Gian_Studio_Offline_Compiler_v0_3_8_NATIVE_AUDIOFX.apk`.

## Teste correto

Depois de instalar a v0.3.8:

1. Gere novamente o Gianplayer usando o `index.html` aprovado.
2. Não reutilize o APK produzido pela v0.3.7.
3. Abra o diagnóstico do equalizador no Gianplayer.
4. O texto deve informar que a ponte Android foi detectada.
5. Reproduza uma música do YouTube e use o teste A/B.

`test_project/index.html` é uma página pequena para confirmar apenas a ponte e o motor AudioFX.

## Limitação do Android

A base tenta aplicar efeitos na sessão global `0`. A ponte poderá ser detectada e o motor poderá ser criado, mas alguns fabricantes não permitem que esse efeito altere o áudio de outro aplicativo ou do player do YouTube. O diagnóstico separa as duas situações:

- ponte ausente: APK criado pela base errada;
- ponte presente e `created:false`: motor bloqueado/indisponível;
- ponte presente e `created:true`, mas sem diferença audível: fabricante ignora o efeito global.
