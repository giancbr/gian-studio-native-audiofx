# v0.3.8 — Native AudioFX Base

- substitui a base Black5 antiga por uma base compilada com Java nativo;
- registra `window.GianCrystalAudioFX` em todos os APKs gerados;
- adiciona Equalizer, BassBoost e LoudnessEnhancer na sessão global 0;
- mantém escolha de HTML/ZIP, nome, pacote, ícone, orientação, câmera, microfone, assinatura e APK v2;
- preserva o motor JavaScript offline do Gian Studio v0.3.7;
- adiciona salvamento nativo de APKs e chaves em `Downloads/GianStudio`;
- inclui teste de ponte e diagnóstico AudioFX;
- inclui workflow de compilação automática em uma única execução.
