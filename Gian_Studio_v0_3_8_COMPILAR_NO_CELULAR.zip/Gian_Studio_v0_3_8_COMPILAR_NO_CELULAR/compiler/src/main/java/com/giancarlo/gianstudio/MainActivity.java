package com.giancarlo.gianstudio;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 601;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new CompilerChromeClient());
        webView.addJavascriptInterface(new NativeDownloadBridge(), "GianStudioNative");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private final class CompilerChromeClient extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            try {
                startActivityForResult(params.createIntent(), PICK_FILE);
                return true;
            } catch (Throwable error) {
                fileCallback = null;
                Toast.makeText(MainActivity.this, "Não foi possível abrir o seletor de arquivos", Toast.LENGTH_LONG).show();
                return false;
            }
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            runOnUiThread(() -> request.grant(request.getResources()));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public final class NativeDownloadBridge {
        @JavascriptInterface
        public boolean saveBase64(String filename, String mimeType, String encoded) {
            try {
                byte[] data = Base64.decode(encoded, Base64.DEFAULT);
                String safeName = filename == null || filename.trim().isEmpty() ? "GianStudio_file.bin" : filename.replaceAll("[\\\\/:*?\"<>|]", "_");
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null ? "application/octet-stream" : mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/GianStudio");
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IllegalStateException("Não foi possível criar o arquivo");
                    try (OutputStream stream = getContentResolver().openOutputStream(uri)) {
                        if (stream == null) throw new IllegalStateException("Fluxo de saída indisponível");
                        stream.write(data);
                    }
                } else {
                    File folder = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "GianStudio");
                    if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Pasta de saída indisponível");
                    try (OutputStream stream = new FileOutputStream(new File(folder, safeName))) {
                        stream.write(data);
                    }
                }
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Salvo em Downloads/GianStudio", Toast.LENGTH_LONG).show());
                return true;
            } catch (Throwable error) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Falha ao salvar: " + error.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }

        @JavascriptInterface public String version() { return "Gian Studio 0.3.8 Native AudioFX"; }
    }
}
