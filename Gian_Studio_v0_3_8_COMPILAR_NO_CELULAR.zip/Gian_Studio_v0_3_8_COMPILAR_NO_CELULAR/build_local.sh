#!/usr/bin/env bash
set -euo pipefail
gradle :audiofxbase:assembleDebug
python3 tools/prepare_compiler_asset.py \
  --base-apk audiofxbase/build/outputs/apk/debug/audiofxbase-debug.apk \
  --template tools/compiler_v037_original.html \
  --output compiler/src/main/assets/www/index.html
gradle :compiler:assembleDebug
mkdir -p output
cp compiler/build/outputs/apk/debug/compiler-debug.apk output/Gian_Studio_Offline_Compiler_v0_3_8_NATIVE_AUDIOFX.apk
echo "APK: output/Gian_Studio_Offline_Compiler_v0_3_8_NATIVE_AUDIOFX.apk"
