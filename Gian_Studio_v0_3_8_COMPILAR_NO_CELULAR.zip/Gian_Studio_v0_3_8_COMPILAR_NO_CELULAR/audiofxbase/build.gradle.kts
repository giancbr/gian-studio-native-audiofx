plugins {
    id("com.android.application")
}

android {
    namespace = "com.exemple.template"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.exemple.template"
        minSdk = 26
        targetSdk = 35
        versionCode = 38
        versionName = "0.3.8-audiofx-base"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
