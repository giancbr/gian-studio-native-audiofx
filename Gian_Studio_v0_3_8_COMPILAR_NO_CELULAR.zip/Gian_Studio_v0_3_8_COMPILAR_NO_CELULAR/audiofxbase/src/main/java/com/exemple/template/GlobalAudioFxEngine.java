package com.exemple.template;

import android.media.audiofx.AudioEffect;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;

import org.json.JSONArray;
import org.json.JSONObject;

final class GlobalAudioFxEngine {
    static final int GLOBAL_SESSION_ID = 0;
    private static final int[] UI_FREQUENCIES_HZ = {31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000};

    private final double[] uiBandDb = new double[UI_FREQUENCIES_HZ.length];
    private Equalizer equalizer;
    private BassBoost bassBoost;
    private LoudnessEnhancer loudness;
    private short bandCount;
    private short minLevelMb = -1200;
    private short maxLevelMb = 1200;
    private int[] centerHz = new int[0];
    private boolean bassStrengthSupported;
    private boolean requestedEnabled;
    private double bassDb;
    private double gainDb;
    private String lastError = "";

    synchronized boolean initialize() {
        if (equalizer != null) return true;
        StringBuilder errors = new StringBuilder();
        try {
            equalizer = new Equalizer(1000, GLOBAL_SESSION_ID);
            bandCount = equalizer.getNumberOfBands();
            short[] range = equalizer.getBandLevelRange();
            if (range != null && range.length >= 2) {
                minLevelMb = range[0];
                maxLevelMb = range[1];
            }
            centerHz = new int[Math.max(0, bandCount)];
            for (short i = 0; i < bandCount; i++) centerHz[i] = equalizer.getCenterFreq(i) / 1000;
        } catch (Throwable error) {
            equalizer = null;
            appendError(errors, "Equalizer", error);
        }
        try {
            bassBoost = new BassBoost(1000, GLOBAL_SESSION_ID);
            bassStrengthSupported = bassBoost.getStrengthSupported();
        } catch (Throwable error) {
            bassBoost = null;
            appendError(errors, "BassBoost", error);
        }
        try {
            loudness = new LoudnessEnhancer(GLOBAL_SESSION_ID);
        } catch (Throwable error) {
            loudness = null;
            appendError(errors, "LoudnessEnhancer", error);
        }
        lastError = errors.toString();
        applyAll();
        applyEnabled();
        return equalizer != null;
    }

    synchronized boolean setEnabled(boolean enabled) {
        requestedEnabled = enabled;
        if (equalizer == null) initialize();
        applyEnabled();
        return equalizer != null && safeEnabled(equalizer) == enabled;
    }

    synchronized boolean setBand(int uiIndex, double db) {
        if (uiIndex < 0 || uiIndex >= uiBandDb.length) return false;
        uiBandDb[uiIndex] = clamp(db, -12.0, 12.0);
        if (equalizer == null) initialize();
        return applyBands();
    }

    synchronized boolean setBass(double db) {
        bassDb = clamp(db, 0.0, 12.0);
        if (bassBoost == null) initialize();
        return applyBass();
    }

    synchronized boolean setGain(double db) {
        gainDb = clamp(db, -6.0, 6.0);
        if (loudness == null) initialize();
        return applyGain();
    }

    synchronized String statusJson() {
        JSONObject out = new JSONObject();
        try {
            out.put("created", equalizer != null);
            out.put("sessionId", GLOBAL_SESSION_ID);
            out.put("requestedEnabled", requestedEnabled);
            out.put("equalizerEnabled", safeEnabled(equalizer));
            out.put("deviceBands", (int) bandCount);
            out.put("minBandDb", minLevelMb / 100.0);
            out.put("maxBandDb", maxLevelMb / 100.0);
            out.put("bassBoostAvailable", bassBoost != null);
            out.put("bassBoostEnabled", safeEnabled(bassBoost));
            out.put("bassStrengthSupported", bassStrengthSupported);
            out.put("bassDb", bassDb);
            out.put("loudnessAvailable", loudness != null);
            out.put("loudnessEnabled", safeEnabled(loudness));
            out.put("gainDb", gainDb);
            out.put("lastError", lastError);
            JSONArray centers = new JSONArray();
            for (int value : centerHz) centers.put(value);
            out.put("centerFrequenciesHz", centers);
        } catch (Throwable error) {
            return "{\"created\":false,\"lastError\":\"Falha ao gerar diagnóstico\"}";
        }
        return out.toString();
    }

    synchronized void release() {
        requestedEnabled = false;
        enableEffect(equalizer, false);
        enableEffect(bassBoost, false);
        enableEffect(loudness, false);
        try { if (equalizer != null) equalizer.release(); } catch (Throwable ignored) {}
        try { if (bassBoost != null) bassBoost.release(); } catch (Throwable ignored) {}
        try { if (loudness != null) loudness.release(); } catch (Throwable ignored) {}
        equalizer = null;
        bassBoost = null;
        loudness = null;
    }

    private void applyAll() { applyBands(); applyBass(); applyGain(); }

    private boolean applyBands() {
        if (equalizer == null) return false;
        try {
            for (short band = 0; band < bandCount; band++) {
                double db = interpolate(Math.max(1, centerHz[band]));
                int mb = (int) Math.round(db * 100.0);
                mb = Math.max(minLevelMb, Math.min(maxLevelMb, mb));
                equalizer.setBandLevel(band, (short) mb);
            }
            return true;
        } catch (Throwable error) {
            recordError("Bandas", error);
            return false;
        }
    }

    private boolean applyBass() {
        if (bassBoost == null) return false;
        try {
            int strength = (int) Math.round((bassDb / 12.0) * 1000.0);
            bassBoost.setStrength((short) Math.max(0, Math.min(1000, strength)));
            return true;
        } catch (Throwable error) {
            recordError("Graves", error);
            return false;
        }
    }

    private boolean applyGain() {
        if (loudness == null) return false;
        try {
            loudness.setTargetGain((int) Math.round(Math.max(0.0, gainDb) * 100.0));
            return true;
        } catch (Throwable error) {
            recordError("Ganho", error);
            return false;
        }
    }

    private void applyEnabled() {
        enableEffect(equalizer, requestedEnabled);
        enableEffect(bassBoost, requestedEnabled);
        enableEffect(loudness, requestedEnabled);
    }

    private double interpolate(int frequencyHz) {
        if (frequencyHz <= UI_FREQUENCIES_HZ[0]) return uiBandDb[0];
        int last = UI_FREQUENCIES_HZ.length - 1;
        if (frequencyHz >= UI_FREQUENCIES_HZ[last]) return uiBandDb[last];
        double target = Math.log(frequencyHz);
        for (int i = 0; i < last; i++) {
            if (frequencyHz <= UI_FREQUENCIES_HZ[i + 1]) {
                double left = Math.log(UI_FREQUENCIES_HZ[i]);
                double right = Math.log(UI_FREQUENCIES_HZ[i + 1]);
                double ratio = (target - left) / Math.max(0.000001, right - left);
                return uiBandDb[i] + (uiBandDb[i + 1] - uiBandDb[i]) * ratio;
            }
        }
        return uiBandDb[last];
    }

    private static void enableEffect(AudioEffect effect, boolean enabled) {
        try { if (effect != null) effect.setEnabled(enabled); } catch (Throwable ignored) {}
    }

    private static boolean safeEnabled(AudioEffect effect) {
        try { return effect != null && effect.getEnabled(); } catch (Throwable ignored) { return false; }
    }

    private static double clamp(double value, double min, double max) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return 0.0;
        return Math.max(min, Math.min(max, value));
    }

    private static void appendError(StringBuilder target, String label, Throwable error) {
        if (target.length() > 0) target.append(" | ");
        target.append(label).append(": ").append(error.getClass().getSimpleName());
        if (error.getMessage() != null && !error.getMessage().trim().isEmpty()) {
            target.append(" (").append(error.getMessage().trim()).append(")");
        }
    }

    private void recordError(String label, Throwable error) {
        StringBuilder builder = new StringBuilder(lastError == null ? "" : lastError);
        appendError(builder, label, error);
        lastError = builder.toString();
    }
}
