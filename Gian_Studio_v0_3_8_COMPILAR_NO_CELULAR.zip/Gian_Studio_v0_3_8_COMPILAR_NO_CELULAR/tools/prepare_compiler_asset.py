#!/usr/bin/env python3
import argparse
import base64
import re
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--base-apk', required=True)
parser.add_argument('--template', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()

base_apk = Path(args.base_apk)
template = Path(args.template)
output = Path(args.output)
if not base_apk.exists():
    raise SystemExit(f'Base APK não encontrada: {base_apk}')

html = template.read_text(encoding='utf-8', errors='strict')
base64_apk = base64.b64encode(base_apk.read_bytes()).decode('ascii')

html, count_base = re.subn(
    r"const\s+BLACK5_BASE_APK_B64\s*=\s*([`'\"])(.*?)\1\s*;",
    lambda m: f"const BLACK5_BASE_APK_B64 = '{base64_apk}';",
    html,
    count=1,
    flags=re.S,
)
html, count_package = re.subn(
    r"const\s+BLACK5_PACKAGE\s*=\s*([`'\"])(.*?)\1\s*;",
    "const BLACK5_PACKAGE = 'com.exemple.template';",
    html,
    count=1,
    flags=re.S,
)
if count_base != 1 or count_package != 1:
    raise SystemExit('Não foi possível localizar as constantes da base no HTML do Gian Studio.')

replacements = {
    'Gian Studio Offline Compiler v0.3.7 — Black5 Base + APK v2': 'Gian Studio Offline Compiler v0.3.8 — Native AudioFX Base',
    'Base Black5 pronta — geração local e offline': 'Base Native AudioFX pronta — geração local e offline',
    'Abrindo a base Android Black5…': 'Abrindo a base Android Native AudioFX…',
    'Copiando a estrutura Black5…': 'Copiando a estrutura Native AudioFX…',
    'A estrutura da base Black5 está incompleta.': 'A estrutura da base Native AudioFX está incompleta.',
    'APK concluído com base Black5, ZIPALIGN e assinatura APK v2.': 'APK concluído com base Native AudioFX, ZIPALIGN e assinatura APK v2.',
}
for old, new in replacements.items():
    html = html.replace(old, new)

# Usa a ponte nativa do novo Gian Studio para salvar blobs grandes no Android.
old_download = '''  function triggerDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    anchor.style.display = 'none';
    document.body.appendChild(anchor);
    anchor.click();
    setTimeout(() => { anchor.remove(); URL.revokeObjectURL(url); }, 60000);
  }'''
new_download = '''  function triggerDownload(blob, filename) {
    const nativeSaver = window.GianStudioNative;
    if (nativeSaver && typeof nativeSaver.saveBase64 === 'function') {
      blob.arrayBuffer().then(buffer => {
        const bytes = new Uint8Array(buffer);
        const chunkSize = 0x8000;
        let binary = '';
        for (let offset = 0; offset < bytes.length; offset += chunkSize) {
          binary += String.fromCharCode(...bytes.subarray(offset, Math.min(bytes.length, offset + chunkSize)));
        }
        const ok = nativeSaver.saveBase64(filename, blob.type || 'application/octet-stream', btoa(binary));
        if (!ok) throw new Error('A ponte Android não conseguiu salvar o arquivo.');
      }).catch(error => alert(`Falha ao salvar: ${error.message || error}`));
      return;
    }
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    anchor.style.display = 'none';
    document.body.appendChild(anchor);
    anchor.click();
    setTimeout(() => { anchor.remove(); URL.revokeObjectURL(url); }, 60000);
  }'''
if old_download not in html:
    raise SystemExit('Função triggerDownload original não encontrada.')
html = html.replace(old_download, new_download, 1)

# Pequeno aviso persistente na tela inicial.
marker = '<body>'
badge = '''<div style="position:fixed;right:10px;bottom:10px;z-index:99999;padding:7px 10px;border-radius:999px;background:#061426e8;border:1px solid #44c8ff66;color:#bcecff;font:700 10px system-ui;box-shadow:0 8px 24px #0007">Native AudioFX • v0.3.8</div>'''
html = html.replace(marker, marker + badge, 1)

output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(html, encoding='utf-8')
print(f'HTML preparado: {output} ({output.stat().st_size} bytes)')
print(f'Base AudioFX incorporada: {base_apk} ({base_apk.stat().st_size} bytes)')
