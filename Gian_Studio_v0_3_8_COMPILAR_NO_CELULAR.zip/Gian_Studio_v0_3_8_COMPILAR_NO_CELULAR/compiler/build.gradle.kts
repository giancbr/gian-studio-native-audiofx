plugins {
    id("com.android.application")
}

android {
    namespace = "com.giancarlo.gianstudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.giancarlo.gianstudio.nativeaudiofx"
        minSdk = 26
        targetSdk = 35
        versionCode = 38
        versionName = "0.3.8"
    }

    buildTypes {
        debug { isMinifyEnabled = false }
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
